Order
PaymentTransaction
PaymentLog

public abstract class BaseEntity
{
    public Guid Id {get; set;} = Guid.NewGuid();
}

public class Order : BaseEntity
{
    
}
public class PaymentTransaction  : BaseEntity
{
    
}
public class PaymentAuditLog : BaseEntity
{
    
}